#Moisés Gutiérrez Guerrero
#06/10/24
#Escriba un programa que escriba las siguientes listas


print(list(range(0,10,1)))
print(list(range(4,11,1)))
print(list(range(-6,0,1)))
print(list(range(-56,-49,1)))
print(list(range(1,18,2)))
print(list(range(-6,11,2)))
print(list(range(100,1001,100)))
print(list(range(10,3,-1)))
print(list(range(-50,-57,-1)))
print(list(range(17,0,-2)))
print(list(range(500,-1,-100)))